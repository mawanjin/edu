CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_country`
--

DROP TABLE IF EXISTS `edu_country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_country` (
  `id` varchar(40) NOT NULL,
  `name` varchar(45) DEFAULT NULL COMMENT ' Ê†áÈ¢ò',
  `img` varchar(45) DEFAULT NULL COMMENT 'ÁôªÂΩïÂêç',
  `del_flag` char(1) DEFAULT NULL COMMENT 'Âà†Èô§Ê†áËÆ∞',
  `remarks` varchar(80) DEFAULT NULL COMMENT 'Â§áÊ≥®',
  `create_by` varchar(64) DEFAULT NULL COMMENT 'ÂàõÂª∫ËÄÖ(ÂÖ≥ËÅîÂà∞Áî®Êà∑Ë°®)',
  `create_date` datetime DEFAULT NULL,
  `update_by` varchar(40) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `hot` tinyint(4) DEFAULT NULL COMMENT '0 ÁÉ≠È',
  `status` tinyint(4) DEFAULT NULL,
  `porder` int(11) DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `create_date_UNIQUE` (`create_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ÂõΩÂÆ∂Ë°®';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_country`
--

LOCK TABLES `edu_country` WRITE;
/*!40000 ALTER TABLE `edu_country` DISABLE KEYS */;
INSERT INTO `edu_country` VALUES ('152977c1fd1648808945d9bd24e5d51b','fd','c35a8e9e40e24581b42e98953634dd0b.png','1','sdaf','1','2015-04-01 00:26:53','1','2015-04-01 00:26:53',NULL,0,0),('379f65bdd3b2486aadeca852bbea9cc8','asdfads','','1','asfasd','1','2015-04-01 00:33:27','1','2015-04-01 00:33:39',1,0,0),('3a589f5d09a24e3b8d23ace5336aed98','澳洲','66403d42ea0f45b2802a3e502372236e.png','0','aa','1','2015-04-01 00:35:17','1','2015-04-19 02:28:58',0,1,0),('60261461e216460e9eafdf50effbbca5','dsafas',NULL,'1','','1','2015-04-01 00:18:18','1','2015-04-01 00:18:18',0,0,0),('67be4291d55d4341ae74ca803372b97d','美国','','0','','1','2015-04-19 02:28:07','1','2015-04-19 02:28:07',0,1,0),('afeb3a9a8ca345d59ce65bc2b9de5592','aaaaaa','1e27b7f59d38461bb73517a6203890b9.png','1','','1','2015-04-13 01:02:24','1','2015-04-13 01:02:24',0,0,0),('cd08ec3109e4488b8c8b7f4d6237ea63','英国','f96655f8fa6a4f428ca6ea8aa4b80d87.jpg','0','sadf','1','2015-04-19 02:03:16','1','2015-04-19 02:29:21',0,1,10),('e1965c7604724035afe91b513e572831','asfs',NULL,'1','asfd','1','2015-04-01 00:18:53','1','2015-04-01 00:18:53',1,0,0);
/*!40000 ALTER TABLE `edu_country` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:54
