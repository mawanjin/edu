CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_teacher`
--

DROP TABLE IF EXISTS `edu_teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_teacher` (
  `id` varchar(40) NOT NULL,
  `name` varchar(45) DEFAULT NULL COMMENT ' 标题',
  `del_flag` char(1) DEFAULT NULL COMMENT '删除标记',
  `remarks` varchar(80) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者(关联到用户表)',
  `create_date` datetime DEFAULT NULL,
  `update_by` varchar(40) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `img` varchar(255) DEFAULT NULL,
  `gendar` tinyint(4) DEFAULT NULL COMMENT '0 男 1女',
  `teach_time` varchar(45) DEFAULT NULL COMMENT '教学时间5年',
  `grade` varchar(45) DEFAULT NULL COMMENT '职称',
  `ability` varchar(255) DEFAULT NULL COMMENT '教学领域',
  `summary` varchar(255) DEFAULT NULL COMMENT '简介',
  `content` text COMMENT '详情',
  `status` tinyint(4) DEFAULT NULL,
  `major_id` varchar(40) DEFAULT NULL COMMENT '专业',
  PRIMARY KEY (`id`),
  UNIQUE KEY `create_date_UNIQUE` (`create_date`),
  KEY `edu_teacher_major` (`major_id`),
  CONSTRAINT `edu_teacher_major` FOREIGN KEY (`major_id`) REFERENCES `edu_major` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='教师表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_teacher`
--

LOCK TABLES `edu_teacher` WRITE;
/*!40000 ALTER TABLE `edu_teacher` DISABLE KEYS */;
INSERT INTO `edu_teacher` VALUES ('32fbbaa7aa444e4eb99155f8ea6e01b4','老师二','0','memo','1','2015-04-01 23:22:52','1','2015-04-20 01:47:52','954d2c98915144d0b71dbc2dc79e4edb.png',0,'1年','博士生导师','化学','简介','<p>\r\n	deatil</p>',1,'bf27ab21ffc34048a99ff6202a7d50fc'),('7ed410586f114933baa7018c61497f33','老师一','0','safas','1','2015-04-01 23:20:37','1','2015-04-20 01:47:44','44cfbbaa311c45fe9b9519e89a643237.png',0,'5年','博士','fda','简介','<p>\r\n	safsdafdsaf</p>',1,'33ab5627543c4a4c9cb07258f47692ee'),('a2ecf882731346b1ab9acb1a63d9367e','好老师','0','','1','2015-04-13 01:15:39','1','2015-04-20 01:47:46','',0,'asdfsaf','fsdfsaf','sdfsafdsafd','dsafas','',1,'14a442a5522c4d25bb26965b6cd6edda'),('aebb7a8a9f1d4136a80995901ad2f6eb','sadf','1','asdf','1','2015-04-01 23:15:05','1','2015-04-01 23:50:41','',0,'asdfas','sdfdsaf','dsafdsaf','sdafdsaf','',0,'14a442a5522c4d25bb26965b6cd6edda'),('bf5ce64e30c24cff9d165838378aacfe','测试老婆','1','','1','2015-04-13 01:14:07','1','2015-04-13 01:14:07','f4d9a06af3f14d72890fae59b5afd120.png',0,'sadfdsf','sdfsaf','fsdafsdafsd','sdfsad','',0,'14a442a5522c4d25bb26965b6cd6edda');
/*!40000 ALTER TABLE `edu_teacher` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:54
