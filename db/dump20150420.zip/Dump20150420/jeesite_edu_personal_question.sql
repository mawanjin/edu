CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_personal_question`
--

DROP TABLE IF EXISTS `edu_personal_question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_personal_question` (
  `id` varchar(40) NOT NULL,
  `title` varchar(225) DEFAULT NULL,
  `img` varchar(200) DEFAULT NULL,
  `summary` varchar(200) DEFAULT NULL,
  `content` text COMMENT '详情',
  `status` tinyint(4) DEFAULT NULL COMMENT '0未发布  1发布',
  `del_flag` char(1) DEFAULT NULL COMMENT '删除标记',
  `remarks` varchar(80) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者(关联到用户表)',
  `create_date` datetime DEFAULT NULL,
  `update_by` varchar(40) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `view_count` int(11) DEFAULT '0' COMMENT '查看个数',
  `personal_category` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_personal_category` (`personal_category`),
  CONSTRAINT `fk_personal_category` FOREIGN KEY (`personal_category`) REFERENCES `edu_question_category` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='个人问答';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_personal_question`
--

LOCK TABLES `edu_personal_question` WRITE;
/*!40000 ALTER TABLE `edu_personal_question` DISABLE KEYS */;
INSERT INTO `edu_personal_question` VALUES ('09d3e294e5754db6b94bec291fec6c6f','tt','9bba2430bd6049beb65beec7b3b332f6.png','asdfdsa','&lt;p&gt;\r\n	safdsaffsd&lt;/p&gt;',1,'0','sdf','1','2015-04-07 23:36:17','1','2015-04-07 23:36:22',0,NULL),('2724daee30914a4d9746f2ce226fd0ab','aaa','c54185e8d0c744179cde4150d0ea822f.png','a','&lt;p&gt;\r\n	a&lt;/p&gt;',0,'0','a','1','2015-04-07 23:49:08','1','2015-04-07 23:52:46',0,'8fed37865e094302bc2e806188b7a87b');
/*!40000 ALTER TABLE `edu_personal_question` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:54
