CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_user_relation`
--

DROP TABLE IF EXISTS `edu_user_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_user_relation` (
  `id` varchar(40) NOT NULL,
  `parent_id` varchar(40) DEFAULT NULL COMMENT ' 标题',
  `student_id` varchar(40) DEFAULT NULL COMMENT '登录名',
  `remarks` varchar(80) DEFAULT NULL,
  `del_flag` char(1) DEFAULT NULL,
  `create_by` varchar(64) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_by` varchar(40) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `edu_user_parent` (`parent_id`),
  KEY `edu_user_student` (`student_id`),
  CONSTRAINT `edu_user_parent` FOREIGN KEY (`parent_id`) REFERENCES `edu_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `edu_user_student` FOREIGN KEY (`student_id`) REFERENCES `edu_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='教育用户关系表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_user_relation`
--

LOCK TABLES `edu_user_relation` WRITE;
/*!40000 ALTER TABLE `edu_user_relation` DISABLE KEYS */;
INSERT INTO `edu_user_relation` VALUES ('0e1c08f7f36f4cfd9f7f01d90e718601','d0b9354bdcf74b7c8e9e6646bce24f76','346b105696874a03a3dd8e4d0ca1f93b',NULL,'1','1','2015-03-31 22:42:14','1','2015-03-31 22:42:14'),('14337679e2784e32a7116b8065e08b78','d0b9354bdcf74b7c8e9e6646bce24f76','07b006aa59c64dbc9ae4dcbc1266acc9',NULL,'0','1','2015-03-31 23:30:01','1','2015-03-31 23:30:01'),('2824626ebe484431ae43061f297c9d35','d0b9354bdcf74b7c8e9e6646bce24f76','5d0059acccc74d09b99b41fac9c11282',NULL,'0','1','2015-03-31 23:30:03','1','2015-03-31 23:30:03'),('46e3b656e90440249ac0ba5e422679f8','d0b9354bdcf74b7c8e9e6646bce24f76','5b5d783cebed4ea7a0570309f9892251',NULL,'0','1','2015-03-31 22:42:24','1','2015-03-31 22:42:24'),('569f09d38c9348bd903a65403f49f38b','d0b9354bdcf74b7c8e9e6646bce24f76','687a669f1ef84df5ad80dadfcfa5a84a',NULL,'1','1','2015-03-31 23:30:04','1','2015-03-31 23:30:04'),('8f7f970b6f5f4db4a9ce2353a9e0a5fd','d0b9354bdcf74b7c8e9e6646bce24f76','346b105696874a03a3dd8e4d0ca1f93b',NULL,'0','1','2015-04-01 00:01:17','1','2015-04-01 00:01:17'),('907d1c1029fb40c5a81cc1433277c003','d0b9354bdcf74b7c8e9e6646bce24f76','3a09c471438246cfabf67b8f95c320df',NULL,'1','1','2015-03-31 22:42:20','1','2015-03-31 22:42:20'),('909869851a224915954b6a6faad3be94','d0b9354bdcf74b7c8e9e6646bce24f76','ca6dc1547b174204abc4eb9339db77a2',NULL,'1','1','2015-03-31 22:34:48','1','2015-03-31 22:34:48'),('e6ffa05dc9414e9d95de9b5befed4985','d0b9354bdcf74b7c8e9e6646bce24f76','0491ea60d3b74ded8dee3d62fe96e2a1',NULL,'1','1','2015-03-31 23:29:25','1','2015-03-31 23:29:25'),('fc85ce4218604209bc4eeeaab2b9a7d9','d0b9354bdcf74b7c8e9e6646bce24f76','6b8056e481bf4c778b545f907df61854',NULL,'1','1','2015-03-31 23:30:05','1','2015-03-31 23:30:05');
/*!40000 ALTER TABLE `edu_user_relation` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:55
