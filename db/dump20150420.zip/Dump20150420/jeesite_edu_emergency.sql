CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_emergency`
--

DROP TABLE IF EXISTS `edu_emergency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_emergency` (
  `id` varchar(40) NOT NULL,
  `title` varchar(225) DEFAULT NULL COMMENT ' 标题',
  `content` text COMMENT '详情',
  `status` tinyint(4) DEFAULT NULL COMMENT '0未发布  1发布',
  `del_flag` char(1) DEFAULT NULL COMMENT '删除标记',
  `remarks` varchar(80) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者(关联到用户表)',
  `create_date` datetime DEFAULT NULL,
  `update_by` varchar(40) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL COMMENT '类型:0重要 1系统',
  `img` varchar(200) DEFAULT NULL,
  `top` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='重要提示';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_emergency`
--

LOCK TABLES `edu_emergency` WRITE;
/*!40000 ALTER TABLE `edu_emergency` DISABLE KEYS */;
INSERT INTO `edu_emergency` VALUES ('257390c3a4624223a0a70ff24eee4fde','系统提示三','<p>\r\n	系统提示三详情</p>',1,'0','abc','1','2015-03-30 23:40:13','1','2015-04-19 01:16:34',0,NULL,0),('6ec43957ba214c7180b7dddd08ad4041','','',0,'1','','1','2015-03-31 00:21:26','1','2015-03-31 00:21:26',0,NULL,0),('91c6031329f74daa8bf90e823ca196eb','系统提示二','<p>\r\n	系统提示二详情</p>',1,'0','sdaf','1','2015-04-19 00:43:33','1','2015-04-19 01:16:23',1,NULL,0),('c88c7cd398ff4321aac518941bcfa819','系统提示四','<p>\r\n	系统提示四</p>',1,'0','','1','2015-04-19 01:25:35','1','2015-04-19 01:25:35',1,'de19302a6771414b966b6a503a6a50f2.jpg',0),('d31ac37685534537b683de0537b70ef6','重要提示一','<p>\r\n	重要提示一详情</p>',1,'0','asafs','1','2015-03-30 23:36:03','1','2015-04-19 01:15:57',0,NULL,0),('f9f8bc334af944929fdcef48afb11653','系统提示一','<p>\r\n	我是系统提示一详情</p>',1,'0','asdfdasf','1','2015-03-30 23:38:24','1','2015-04-19 01:15:37',1,NULL,1);
/*!40000 ALTER TABLE `edu_emergency` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:56
