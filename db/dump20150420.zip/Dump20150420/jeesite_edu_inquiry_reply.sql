CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_inquiry_reply`
--

DROP TABLE IF EXISTS `edu_inquiry_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_inquiry_reply` (
  `id` varchar(40) NOT NULL,
  `name` varchar(40) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL COMMENT '回复内容',
  `status` tinyint(4) DEFAULT NULL COMMENT '0未发布  1发布',
  `del_flag` char(1) DEFAULT NULL COMMENT '删除标记',
  `remarks` varchar(80) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者(关联到用户表)',
  `create_date` datetime DEFAULT NULL,
  `update_by` varchar(40) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `inquiry` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_inquiry_reply` (`inquiry`),
  KEY `fk_inquiry_user1` (`name`),
  CONSTRAINT `fk_inquiry_reply` FOREIGN KEY (`inquiry`) REFERENCES `edu_inquiry` (`id`),
  CONSTRAINT `fk_inquiry_user1` FOREIGN KEY (`name`) REFERENCES `edu_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='留言回复';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_inquiry_reply`
--

LOCK TABLES `edu_inquiry_reply` WRITE;
/*!40000 ALTER TABLE `edu_inquiry_reply` DISABLE KEYS */;
INSERT INTO `edu_inquiry_reply` VALUES ('690d87d4c9d64b9282a8ce59393d0bb0','0491ea60d3b74ded8dee3d62fe96e2a1','t',NULL,'0',NULL,'1','2015-04-09 02:31:27','1','2015-04-09 02:31:27','462ff82a511d4a768a095084548799e3'),('75e77a4c703f41979b85b590d46afd7b','0491ea60d3b74ded8dee3d62fe96e2a1','g',NULL,'0',NULL,'1','2015-04-09 02:32:46','1','2015-04-09 02:32:46','462ff82a511d4a768a095084548799e3'),('8962458c04bf45d098cfa7e872440b05','0491ea60d3b74ded8dee3d62fe96e2a1','aaa',NULL,'0',NULL,'1','2015-04-09 02:34:39','1','2015-04-09 02:34:39','06a3746c6def497c931c847bd945ac1e'),('8c5690c8a0354d75bf616dd7cd3c3628','07b006aa59c64dbc9ae4dcbc1266acc9','asfsaf',NULL,'0',NULL,'1','2015-04-09 02:35:08','1','2015-04-09 02:35:08','b756a6aa4fd5414ea0e25ef7811e6ac3'),('ae4aa56323cf4374860c22f9aaacfc6e','346b105696874a03a3dd8e4d0ca1f93b','a',NULL,'0',NULL,'1','2015-04-09 02:36:02','1','2015-04-09 02:36:02','a75c0de47d8d4b55b22b8cb75edc8bbf'),('c350321f3a914afbbcc2d3dd07dc3671','0491ea60d3b74ded8dee3d62fe96e2a1','a',NULL,'0',NULL,'1','2015-04-09 02:23:18','1','2015-04-09 02:23:18','462ff82a511d4a768a095084548799e3'),('d7ea629931ce41f6b00ec6e0b683e9c8','0491ea60d3b74ded8dee3d62fe96e2a1','sdfsaf',NULL,'0',NULL,'1','2015-04-12 22:44:54','1','2015-04-12 22:44:54','a75c0de47d8d4b55b22b8cb75edc8bbf'),('e45ff9bee5fc4747906dbbe97fdae1f8','0491ea60d3b74ded8dee3d62fe96e2a1','wwwww',NULL,'0',NULL,'1','2015-04-09 02:24:58','1','2015-04-09 02:24:58','462ff82a511d4a768a095084548799e3'),('e8d80010c82946b3b1b2442b5d0784b7','0491ea60d3b74ded8dee3d62fe96e2a1','m',NULL,'0',NULL,'1','2015-04-09 02:33:57','1','2015-04-09 02:33:57','462ff82a511d4a768a095084548799e3');
/*!40000 ALTER TABLE `edu_inquiry_reply` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:56
