CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_user`
--

DROP TABLE IF EXISTS `edu_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_user` (
  `id` varchar(40) NOT NULL,
  `name` varchar(45) DEFAULT NULL COMMENT ' 标题',
  `login_name` varchar(45) DEFAULT NULL COMMENT '登录名',
  `nick_name` varchar(45) DEFAULT NULL COMMENT '昵称',
  `del_flag` char(1) DEFAULT NULL COMMENT '删除标记',
  `remarks` varchar(80) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者(关联到用户表)',
  `create_date` datetime DEFAULT NULL,
  `update_by` varchar(40) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `type` tinyint(4) DEFAULT NULL COMMENT '0:家长 1学生 3:管理员',
  `password` varchar(45) DEFAULT NULL COMMENT '密码',
  `school` varchar(40) DEFAULT NULL,
  `teach_time` varchar(45) DEFAULT NULL,
  `birth` date DEFAULT NULL,
  `ability` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_user_school` (`school`),
  CONSTRAINT `fk_user_school` FOREIGN KEY (`school`) REFERENCES `edu_school` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='教育用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_user`
--

LOCK TABLES `edu_user` WRITE;
/*!40000 ALTER TABLE `edu_user` DISABLE KEYS */;
INSERT INTO `edu_user` VALUES ('0491ea60d3b74ded8dee3d62fe96e2a1','sfasfasdf','asfasf','safdsaf','0','safs','1','2015-03-31 00:17:25','1','2015-03-31 00:17:25',0,'a',NULL,NULL,NULL,NULL),('07b006aa59c64dbc9ae4dcbc1266acc9','asfsaf','','','0','','1','2015-03-31 00:18:44','1','2015-03-31 00:18:44',0,'',NULL,NULL,NULL,NULL),('2597fd69af0240759bca80acd2f7d5bc','asdfdsafdsaf',NULL,NULL,'1','asfads','1','2015-03-31 00:00:35','1','2015-03-31 00:01:17',2,NULL,NULL,NULL,NULL,NULL),('2ba809c665384818a52c4f7233f47f73','sfdasfsaf','dasfasf','asdfasf','0','','1','2015-04-13 00:35:36','1','2015-04-13 00:35:36',0,'11111',NULL,NULL,NULL,NULL),('346b105696874a03a3dd8e4d0ca1f93b','a','abc','ddd','0','ccc','1','2015-03-31 00:04:22','1','2015-03-31 00:04:22',0,NULL,NULL,NULL,NULL,NULL),('3a09c471438246cfabf67b8f95c320df','safsf','asfsaf','safsfs','0','','1','2015-03-31 00:16:28','1','2015-03-31 00:16:28',0,'safsa',NULL,NULL,NULL,NULL),('414af5a494b14902a44ec9abbdf84b34','asfsaf','safsaf','asfasf','0','','1','2015-03-31 01:11:31','1','2015-03-31 01:11:31',3,'12345',NULL,NULL,NULL,NULL),('5b5d783cebed4ea7a0570309f9892251','sfasf','asfas','asfda','0','saf','1','2015-03-31 00:18:01','1','2015-03-31 00:18:01',0,'a',NULL,NULL,NULL,NULL),('5d0059acccc74d09b99b41fac9c11282','asfsaf','safsadf','safsafsa','0','sadfasf','1','2015-03-31 00:09:29','1','2015-03-31 00:09:29',0,'asdf,asdfdsfs',NULL,NULL,NULL,NULL),('687a669f1ef84df5ad80dadfcfa5a84a','asdfasf','saf','fas','0','','1','2015-03-31 00:25:03','1','2015-03-31 00:25:03',0,'',NULL,NULL,NULL,NULL),('6b8056e481bf4c778b545f907df61854','safdsaf','safadsf','saf','0','','1','2015-03-31 00:26:16','1','2015-03-31 00:26:16',0,'',NULL,NULL,NULL,NULL),('7cccfa66f3dc4889abc24364ac15595e','','','','1','','1','2015-03-31 00:21:12','1','2015-03-31 00:21:12',0,NULL,NULL,NULL,NULL,NULL),('81262d41dae74cf18f3cca7af14e6149','黄强','sdf','sadf','0','sdf','1','2015-04-13 00:18:06','1','2015-04-13 00:18:06',0,'123456','8879f15ab2384c4d9f7aa8f623a76b8c',NULL,NULL,NULL),('8204a3561c1b4422b974997071ce2a3d','safsadf','asdfas','asdfas','0','','1','2015-03-31 00:28:26','1','2015-03-31 00:28:26',0,'aadfsdf',NULL,NULL,NULL,NULL),('980a46696c514bf5b5c729e7cb3b9496','','','','1','','1','2015-03-31 00:18:59','1','2015-03-31 00:18:59',0,'',NULL,NULL,NULL,NULL),('9b69d9dd390b4314a2e843a9c0ec481c','','','','1','','1','2015-03-31 00:19:24','1','2015-03-31 00:19:24',0,'',NULL,NULL,NULL,NULL),('a9cb48d2a98c45d384b45a7b5900c274','saasfsa','asfdsaf','asfasf','0','asfas','1','2015-03-31 00:38:28','1','2015-03-31 00:38:28',0,'12345',NULL,NULL,NULL,NULL),('ad9a663b24474021ae710858ed6027b5','saffsa','asf','asdfa','0','','1','2015-03-31 00:24:22','1','2015-04-13 00:18:41',0,'','65ef1037df3c4ea59adc72c7d37100eb',NULL,NULL,NULL),('ca6dc1547b174204abc4eb9339db77a2','李强','asfsa','asfs','0','','1','2015-03-31 00:23:47','1','2015-04-13 00:43:06',0,'','9a98047d3a04499a8d1f7d91f33b99c9',NULL,NULL,NULL),('d0b9354bdcf74b7c8e9e6646bce24f76','123','asfdsaf','asfddas','0','afdsa','1','2015-03-31 00:30:47','1','2015-04-14 22:21:22',0,'',NULL,'','2015-04-13',''),('e6f1baa8674746f4a39bcbe7dd94c0e8','saf',NULL,NULL,'1','safas','1','2015-03-31 00:01:29','1','2015-03-31 00:01:29',0,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `edu_user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:54
