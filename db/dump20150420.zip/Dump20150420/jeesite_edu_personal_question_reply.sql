CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_personal_question_reply`
--

DROP TABLE IF EXISTS `edu_personal_question_reply`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_personal_question_reply` (
  `id` varchar(40) NOT NULL,
  `name` varchar(40) DEFAULT NULL,
  `content` varchar(200) DEFAULT NULL COMMENT '回复内容',
  `status` tinyint(4) DEFAULT NULL COMMENT '0未发布  1发布',
  `del_flag` char(1) DEFAULT NULL COMMENT '删除标记',
  `remarks` varchar(80) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者(关联到用户表)',
  `create_date` datetime DEFAULT NULL,
  `update_by` varchar(40) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `personal_question` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_personal_reply_user` (`name`),
  KEY `fk_personal_` (`personal_question`),
  CONSTRAINT `fk_personal_` FOREIGN KEY (`personal_question`) REFERENCES `edu_personal_question` (`id`),
  CONSTRAINT `fk_personal_reply_user` FOREIGN KEY (`name`) REFERENCES `edu_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='个人问答回复';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_personal_question_reply`
--

LOCK TABLES `edu_personal_question_reply` WRITE;
/*!40000 ALTER TABLE `edu_personal_question_reply` DISABLE KEYS */;
INSERT INTO `edu_personal_question_reply` VALUES ('1e7374e723b644e289bbc8445dc18600','346b105696874a03a3dd8e4d0ca1f93b','a',NULL,'0',NULL,'1','2015-04-09 00:46:02','1','2015-04-09 00:46:02','2724daee30914a4d9746f2ce226fd0ab'),('245dacbb29ce43a8ad4e136072828868','0491ea60d3b74ded8dee3d62fe96e2a1','sdafdasf',NULL,'0','abc','1','2015-04-09 00:33:48','1','2015-04-09 00:33:48',NULL),('2eab3d630bc44197862ceb5234564e2f','0491ea60d3b74ded8dee3d62fe96e2a1','sadfds',NULL,'0','abc','1','2015-04-09 00:24:10','1','2015-04-09 00:24:10',NULL),('d3ee7850f14d4a49957cb04b070bea4c','0491ea60d3b74ded8dee3d62fe96e2a1','aa',NULL,'1','abc','1','2015-04-09 00:36:51','1','2015-04-09 00:36:51','2724daee30914a4d9746f2ce226fd0ab'),('e616c8aa56354ca392402191a35edbe4','0491ea60d3b74ded8dee3d62fe96e2a1','gggg1',NULL,'1',NULL,'1','2015-04-09 00:42:18','1','2015-04-09 00:42:28','2724daee30914a4d9746f2ce226fd0ab');
/*!40000 ALTER TABLE `edu_personal_question_reply` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:54
