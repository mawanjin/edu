CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_inquiry`
--

DROP TABLE IF EXISTS `edu_inquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_inquiry` (
  `id` varchar(40) NOT NULL,
  `title` varchar(225) DEFAULT NULL,
  `content` text COMMENT '详情',
  `status` tinyint(4) DEFAULT NULL COMMENT '0未发布  1发布',
  `del_flag` char(1) DEFAULT NULL COMMENT '删除标记',
  `remarks` varchar(80) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者(关联到用户表)',
  `create_date` datetime DEFAULT NULL,
  `update_by` varchar(40) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `view_count` int(11) DEFAULT NULL COMMENT '查看个数',
  `type` int(11) DEFAULT NULL COMMENT '类别：\n0 生活便利',
  `user` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `fk_inquiry_user` (`user`),
  CONSTRAINT `fk_inquiry_user` FOREIGN KEY (`user`) REFERENCES `edu_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='留言列表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_inquiry`
--

LOCK TABLES `edu_inquiry` WRITE;
/*!40000 ALTER TABLE `edu_inquiry` DISABLE KEYS */;
INSERT INTO `edu_inquiry` VALUES ('06a3746c6def497c931c847bd945ac1e','abc','sadfdsaf',NULL,'0',NULL,'1','2015-04-09 01:33:59','1','2015-04-09 01:34:48',12,2,'0491ea60d3b74ded8dee3d62fe96e2a1'),('462ff82a511d4a768a095084548799e3','aa','sdf',NULL,'0',NULL,'1','2015-04-09 01:36:51','1','2015-04-09 01:36:51',0,0,'0491ea60d3b74ded8dee3d62fe96e2a1'),('a75c0de47d8d4b55b22b8cb75edc8bbf','sadf','sfa',NULL,'0',NULL,'1','2015-04-09 01:36:58','1','2015-04-09 01:36:58',0,3,'0491ea60d3b74ded8dee3d62fe96e2a1'),('b756a6aa4fd5414ea0e25ef7811e6ac3','a','a',NULL,'0',NULL,'1','2015-04-09 01:36:28','1','2015-04-09 01:36:28',0,1,'0491ea60d3b74ded8dee3d62fe96e2a1'),('cb97542f705c4262bfbc245afd713210','abc','sadfdsaf',NULL,'1',NULL,'1','2015-04-09 01:33:16','1','2015-04-09 01:33:16',12,0,'0491ea60d3b74ded8dee3d62fe96e2a1');
/*!40000 ALTER TABLE `edu_inquiry` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:56
