CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_indeximg`
--

DROP TABLE IF EXISTS `edu_indeximg`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_indeximg` (
  `id` varchar(40) NOT NULL,
  `img` varchar(200) DEFAULT NULL,
  `porder` tinyint(4) DEFAULT NULL COMMENT '顺序 数字越大排越高',
  `del_flag` char(1) DEFAULT NULL COMMENT '删除标记',
  `remarks` varchar(80) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者(关联到用户表)',
  `update_by` varchar(40) DEFAULT NULL,
  `create_date` datetime DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `name` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='首页顶部图片';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_indeximg`
--

LOCK TABLES `edu_indeximg` WRITE;
/*!40000 ALTER TABLE `edu_indeximg` DISABLE KEYS */;
INSERT INTO `edu_indeximg` VALUES ('174a87aa094e4c82acbfee3372fe0e62','f04bc8ea012b4f71bc04d9fd58345b15.png',1,'1','sdfas','1','1','2015-03-29 23:15:14','2015-03-29 23:15:14',0,'afsdf'),('48cf06bbd6af49f58ccecc1a15989018',NULL,13,'1','sdfds','1','1','2015-03-29 23:09:21','2015-03-29 23:11:59',1,'fsdfsadf'),('6eaf62d8089742ba8f247f8aa9810236',NULL,0,'1','dsfa','1','1','2015-03-29 23:08:58','2015-03-29 23:08:58',0,'safs,1'),('85fe6269c9c140999a44b86c19b4738c',NULL,0,'1','fasdf','1','1','2015-03-29 23:01:04','2015-03-29 23:11:57',1,'asf'),('ed96dca132ad47febbac9ee0da0c1220','',0,'1','','1','1','2015-03-31 00:21:43','2015-03-31 00:21:43',0,'');
/*!40000 ALTER TABLE `edu_indeximg` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:55
