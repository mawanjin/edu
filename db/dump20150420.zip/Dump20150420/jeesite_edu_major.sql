CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_major`
--

DROP TABLE IF EXISTS `edu_major`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_major` (
  `id` varchar(40) NOT NULL,
  `name` varchar(45) DEFAULT NULL COMMENT ' 标题',
  `del_flag` char(1) DEFAULT NULL COMMENT '删除标记',
  `remarks` varchar(80) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者(关联到用户表)',
  `create_date` datetime DEFAULT NULL,
  `update_by` varchar(40) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `create_date_UNIQUE` (`create_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='专业表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_major`
--

LOCK TABLES `edu_major` WRITE;
/*!40000 ALTER TABLE `edu_major` DISABLE KEYS */;
INSERT INTO `edu_major` VALUES ('14a442a5522c4d25bb26965b6cd6edda','文学','0','','1','2015-04-01 22:48:48','1','2015-04-01 22:48:48'),('33ab5627543c4a4c9cb07258f47692ee','教育学','0','','1','2015-04-01 22:48:54','1','2015-04-01 22:48:54'),('4b1e5a325d844ec3b46bd877231a8ce7','法学','0','','1','2015-04-01 22:48:00','1','2015-04-01 22:48:00'),('5d5f55489b594c039d3f4276164c83d4','历史学','0','','1','2015-04-01 22:48:30','1','2015-04-01 22:48:30'),('8d9fb0a3532845919a27fc5323be31e1','经济学','0','','1','2015-04-01 22:47:40','1','2015-04-01 22:47:55'),('95cf2ac5b77949dca9f336888782b2be','理学','0','','1','2015-04-01 22:48:35','1','2015-04-01 22:48:35'),('bf27ab21ffc34048a99ff6202a7d50fc','数学','0','','1','2015-04-01 22:48:23','1','2015-04-01 22:48:23'),('c7d0de426bc54500ac6680f28824943c','气象学','0','','1','2015-04-01 22:48:41','1','2015-04-01 22:48:41');
/*!40000 ALTER TABLE `edu_major` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:55
