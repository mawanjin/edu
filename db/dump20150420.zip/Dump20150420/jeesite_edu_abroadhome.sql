CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_abroadhome`
--

DROP TABLE IF EXISTS `edu_abroadhome`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_abroadhome` (
  `id` varchar(40) NOT NULL,
  `title` varchar(225) DEFAULT NULL,
  `img` varchar(200) DEFAULT NULL,
  `summary` varchar(200) DEFAULT NULL,
  `content` text COMMENT '详情',
  `status` tinyint(4) DEFAULT NULL COMMENT '0未发布  1发布',
  `del_flag` char(1) DEFAULT NULL COMMENT '删除标记',
  `remarks` varchar(80) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者(关联到用户表)',
  `create_date` datetime DEFAULT NULL,
  `update_by` varchar(40) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='海外之家';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_abroadhome`
--

LOCK TABLES `edu_abroadhome` WRITE;
/*!40000 ALTER TABLE `edu_abroadhome` DISABLE KEYS */;
INSERT INTO `edu_abroadhome` VALUES ('15ab887bc6484371a06e660e5624f244','sadfsaf','366aed4b72b24cfbbb6dccf1d8ca413d.png','sadfsdaf','&lt;p&gt;\r\n	dsafds&lt;/p&gt;',0,'0','sdafsa','1','2015-04-07 22:52:04','1','2015-04-07 22:52:04'),('f343318f150a4f2981b8b5df6a71c226','dsafdsf','80106c69e30a4a04b41244ce68f99997.png','fsaf','&lt;p&gt;\r\n	safds&lt;/p&gt;',1,'0','sdfasd','1','2015-04-07 22:52:32','1','2015-04-07 22:55:13');
/*!40000 ALTER TABLE `edu_abroadhome` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:56
