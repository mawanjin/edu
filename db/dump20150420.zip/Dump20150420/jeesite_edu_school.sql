CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_school`
--

DROP TABLE IF EXISTS `edu_school`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_school` (
  `id` varchar(40) NOT NULL,
  `name` varchar(45) DEFAULT NULL COMMENT ' 标题',
  `img` varchar(45) DEFAULT NULL COMMENT '登录名',
  `del_flag` char(1) DEFAULT NULL COMMENT '删除标记',
  `remarks` varchar(80) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(64) DEFAULT NULL COMMENT '创建者(关联到用户表)',
  `create_date` datetime DEFAULT NULL,
  `update_by` varchar(40) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `grade` tinyint(4) DEFAULT NULL COMMENT '学校等�',
  `summary` varchar(255) DEFAULT NULL,
  `content` text,
  `status` bigint(20) DEFAULT NULL,
  `badge` varchar(45) DEFAULT NULL,
  `country` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `create_date_UNIQUE` (`create_date`),
  KEY `fk_school_country_idx` (`country`),
  CONSTRAINT `fk_school_country` FOREIGN KEY (`country`) REFERENCES `edu_country` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='学校表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_school`
--

LOCK TABLES `edu_school` WRITE;
/*!40000 ALTER TABLE `edu_school` DISABLE KEYS */;
INSERT INTO `edu_school` VALUES ('65ef1037df3c4ea59adc72c7d37100eb','sfsfsfas','e804bc225bb541b3872b1555fe30cd9f.png','1','asdfa','1','2015-04-01 00:55:09','1','2015-04-01 00:55:19',0,'safsadf','&lt;p&gt;\r\n	sadfasdf&lt;/p&gt;',0,NULL,NULL),('7fc8f2b8a8b14113bd8734c393381a00','lala','566a84265c134946abaddbd0c0c94fbe.png','0','','1','2015-04-13 02:07:20','1','2015-04-19 15:15:49',0,'sadfads','',0,'0535099415d0488692d09d2a821bff5f.png','3a589f5d09a24e3b8d23ace5336aed98'),('8879f15ab2384c4d9f7aa8f623a76b8c','asfsadf','','1','saf','1','2015-04-01 00:59:54','1','2015-04-01 00:59:54',0,'asfadsf','&lt;p&gt;\r\n	asfads&lt;/p&gt;',0,NULL,NULL),('9a98047d3a04499a8d1f7d91f33b99c9','学校一','b069472b08f84312b48fed419638ce17.png','0','dsaf','1','2015-04-13 00:42:43','1','2015-04-19 15:15:40',0,'sadfsfs','<p>\r\n	aa</p>',0,'','67be4291d55d4341ae74ca803372b97d');
/*!40000 ALTER TABLE `edu_school` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:55
