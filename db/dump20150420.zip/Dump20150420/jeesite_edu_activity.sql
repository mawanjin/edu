CREATE DATABASE  IF NOT EXISTS `jeesite` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `jeesite`;
-- MySQL dump 10.13  Distrib 5.6.13, for osx10.6 (i386)
--
-- Host: 127.0.0.1    Database: jeesite
-- ------------------------------------------------------
-- Server version	5.6.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `edu_activity`
--

DROP TABLE IF EXISTS `edu_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `edu_activity` (
  `id` varchar(40) NOT NULL,
  `title` varchar(225) DEFAULT NULL,
  `img` varchar(200) DEFAULT NULL,
  `summary` varchar(200) DEFAULT NULL,
  `content` text COMMENT '详情',
  `status` tinyint(4) DEFAULT NULL COMMENT '0未发布  1发布',
  `del_flag` char(1) DEFAULT NULL COMMENT '删除标记',
  `remarks` varchar(255) DEFAULT NULL COMMENT '备注',
  `create_by` varchar(40) DEFAULT NULL COMMENT '创建者(关联到用户表)',
  `create_date` datetime DEFAULT NULL,
  `update_by` varchar(40) DEFAULT NULL,
  `update_date` datetime DEFAULT NULL,
  `top` char(1) DEFAULT '0' COMMENT '是否为最上面的',
  PRIMARY KEY (`id`),
  KEY `fk_user_activity_idx` (`create_by`,`update_by`),
  KEY `fk_user_activity_upateby` (`update_by`),
  CONSTRAINT `fk_user_activity` FOREIGN KEY (`create_by`) REFERENCES `sys_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_user_activity_upateby` FOREIGN KEY (`update_by`) REFERENCES `sys_user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='主题活动';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `edu_activity`
--

LOCK TABLES `edu_activity` WRITE;
/*!40000 ALTER TABLE `edu_activity` DISABLE KEYS */;
INSERT INTO `edu_activity` VALUES ('0e4b40fcefe54d4f8a88b39f18a253f0','adsf',NULL,NULL,NULL,NULL,'1','a','1','2015-03-25 00:30:28','1','2015-03-25 00:30:28',NULL),('2118ed8610d040629036f7c62e3a3911','b',NULL,NULL,NULL,NULL,'1','b','1','2015-03-25 00:30:39','1','2015-03-25 00:30:39',NULL),('29633cbe5cbf432cb0e4d8553315b849','test','','a',NULL,0,'1','fsa','1','2015-03-29 21:05:34','1','2015-03-29 21:05:34',NULL),('2d5cd921aea5463eb56aa5eb64b9d8ed','sdafdsaf','','sdfdsf','<p>\r\n	sdafdsaf</p>',1,'0','sdafsaf','1','2015-04-18 22:43:53','1','2015-04-18 22:43:53','0'),('47111942345e409cac548e2df41a2dae','123','','123','&lt;p&gt;\r\n	sdafdasfdsaf&lt;/p&gt;',0,'1','','1','2015-04-13 01:18:20','1','2015-04-14 23:23:26','0'),('496e81ae166540279f1e24085319bdf7','11','','sadfasf','&lt;p&gt;\r\n	asdf&lt;/p&gt;',0,'1','sdfa','1','2015-03-29 22:32:20','1','2015-03-29 22:32:20','0'),('5cd0fa1db3c94739bfdbbe9d08808728','asdf1',NULL,NULL,NULL,NULL,'1','sdf','1','2015-03-25 00:29:22','1','2015-03-25 00:30:15',NULL),('65a4592553c440168fdc142eb3fb1469','asdfasd','c6015383e02949cbb1d1ece7b3cfff70.png','asfdsaf','<p>\r\n	我是详情</p>',1,'0','sdfdsaf','1','2015-03-29 21:15:47','1','2015-04-18 22:13:38','0'),('77318e3e4fe842da9414e5d5ac7a0b47','safsdaf','','dsafsaf','<p>\r\n	sadfdsa</p>',1,'0','sadf','1','2015-04-18 22:43:29','1','2015-04-18 22:43:32','0'),('78495ae940864f31aba4e884149e35c0','a','','sadf',NULL,1,'1','asdf','1','2015-03-29 21:07:35','1','2015-03-29 21:07:35',NULL),('7a4f6dfb5cfd46c8aaf7d39a14128ff3','abc',NULL,'adfasdf',NULL,1,'1','sdafaaaa','1','2015-03-25 00:44:16','1','2015-03-25 00:44:22',NULL),('89e47713773244029e5d3a5b93b9d781','asfsd',NULL,'sadfdsaf',NULL,0,'1','asfdsafdsfas','1','2015-03-29 20:52:19','1','2015-03-29 20:52:19',NULL),('8b60452ef4ae4eaa8d59e64795eec6ec','safsda','','fsfsa','<p>\r\n	safads</p>',1,'0','sdfdsaf','1','2015-04-18 22:43:37','1','2015-04-18 22:43:41','0'),('accdbd671dc74757baa939e8b7e330c5','w','','q','&lt;p&gt;\r\n	q&lt;/p&gt;',1,'1','asdfdsaf','1','2015-03-29 22:06:36','1','2015-03-29 22:54:00','0'),('b0ad92f7c1614490bc2157981171ddf6','r','885dd2e1b01b48a2bde4790310362ab1.png','dsaf',NULL,0,'1','fsda','1','2015-03-29 21:10:01','1','2015-03-29 21:10:01',NULL),('c803d698dbd84d3e8d97048d04abbaba','1ee1','5e38be87e4a0450fb214d4d172377473.png','sadf','<p>\r\n	<img alt=\"\" src=\"/edu/userfiles/1/images/edu/activity/2015/03/abc.png\" style=\"width: 140px; height: 140px;\" />safdsafdsfdsaf123</p>',1,'0','afd','1','2015-03-29 21:52:54','1','2015-04-18 22:13:46','1');
/*!40000 ALTER TABLE `edu_activity` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-04-20  3:01:56
